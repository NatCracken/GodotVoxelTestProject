using Godot;
using System;

public partial class TerrainCarver : VoxelLodTerrain
{
    VoxelToolLodTerrain tools;
    public override void _Ready()
    {
        tools = GetVoxelTool() as VoxelToolLodTerrain;
    }

    double canNextFire = 0f;
    public override void _Process(double delta)
    {
        canNextFire -= delta;
        if (Input.IsMouseButtonPressed(MouseButton.Left) && canNextFire < 0)
        {
            canNextFire = 1f;
            CleanFloatingChunks();
        }
    }

    [Export]
    Node3D target;
    [Export]
    float size = 32;
    private void CleanFloatingChunks()
    {
        Vector3 sizeVec = new(size, size, size);
        Aabb bound = new(target.GlobalPosition - sizeVec * 0.5f, sizeVec);
        Godot.Collections.Array chunks = tools.SeparateFloatingChunks(bound, this);
        GD.Print(chunks.Count);
        foreach (Variant chunk in chunks) GD.Print(chunk.VariantType);
    }
}
